---
name: Brand Compliance Assistant
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464554'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#712ae2'
  on-tertiary: '#ffffff'
  tertiary-container: '#8a4cfc'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#5a00c6'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  code-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system projects authority, technological intelligence, and absolute accuracy. Tailored for enterprise legal, creative, and regulatory governance teams, the aesthetic bridges sophisticated modern SaaS software with regulatory-grade clarity.

### Personality & Emotional Resonance
- **Trustworthy & Authoritative:** The interface establishes unwavering confidence through deliberate structure, deep slate typography, and high-contrast legibility.
- **Intelligent & Fluid:** AI-driven assessments feel instantaneous, ambient, and supportive rather than intrusive or experimental.
- **Surgical Precision:** Every border, divider, and token conveys accuracy; data tables, audit logs, and compliance scorecards prioritize scanability and immediate risk triage.

### Visual Style
The aesthetic aligns with modern high-end enterprise platforms:
- Crisp white canvas layered against cool slate tinted backgrounds (`#f8fafc` and `#f1f5f9`).
- Structural 1px division lines using slate borders to keep complex dashboards organized.
- Refined indigo and violet focal accents that denote AI processing, primary actions, and interactive affordances.
- Uncompromising semantic compliance indicators that communicate risk posture without overwhelming the visual field.

## Colors

The color system delivers maximum visual hierarchy while avoiding sensory fatigue during prolonged audit sessions.

### Core Architecture
- **Primary & Interactive (`#6366f1` / `#4f46e5`):** Reserved for primary workflow drivers, active sidebar navigation selections, focal toggles, and primary interactive links.
- **AI & Synthesis (`#7c3aed`):** Applied exclusively to automated brand analysis badges, AI copilot insights, and auto-remediation triggers.
- **Neutral Foundations:**
  - Base Canvas: `#ffffff`
  - Subtle Page Underlay: `#f8fafc`
  - Control & Surface Tiers: `#f1f5f9`
  - Subtle Structural Borders: `#e2e8f0`
  - Strong Border Elements: `#cbd5e1`
  - Primary Typography: `#0f172a`
  - Secondary/Muted Typography: `#475569`
  - Inactive/Helper Typography: `#94a3b8`

### Semantic Compliance Tokens
- **Compliant / Approved (`#10b981`):** Indicates verified assets, adhered guidelines, and cleared checks. Accompanied by `#ecfdf5` background tints and `#a7f3d0` border definitions.
- **Warning / Moderate Deviation (`#f59e0b`):** Signifies non-critical tone shifts or soft guideline conflicts. Paired with `#fffbeb` surfaces and `#fde68a` borders.
- **Critical Violation (`#ef4444`):** Flags legal, trademark, or visual identity violations. Paired with `#fef2f2` surfaces and `#fecaca` borders.
- **Pending / Neutral Scan (`#0ea5e9`):** Represents background analysis, queue progression, or unreviewed states. Paired with `#f0f9ff` surfaces.

## Typography

Typography balances geometric structure and reading stamina across complex enterprise panels.

- **Display & Headings:** `Plus Jakarta Sans` provides sharp, contemporary clarity for titles, metrics, summary card headings, and navigation roots. Slight negative letter spacing (`-0.01em` to `-0.025em`) ensures an anchored, polished tone.
- **Body & Data Grid:** `Inter` handles operational text, compliance rule narratives, legal disclaimers, data cells, and forms.
- **Numbers & Metrics:** Tabular figures are enforced for compliance scores, timestamp lists, and numerical confidence scores to maintain vertical alignment throughout high-density reporting views.

## Layout & Spacing

The layout architecture employs a rigid application frame designed for dense workflows.

### Grid & Layout Structure
- **Persistent Left Workspace Shell:**
  - Fixed 260px desktop navigation rail containing workspace pickers, violation triage links, and system settings.
  - Collapses to an 72px icon-only state on tablet displays (768px – 1024px).
  - Converts into a sliding drawer on viewports below 768px.
- **Header & Breadcrumb Bar:**
  - Fixed 64px vertical height, housing hierarchy breadcrumbs, global rule search, pending scan indicators, and user controls.
- **Main Canvas:**
  - Fluid-width main container framed by a maximum content container of 1600px for multi-column dashboards.
  - Standard 12-column layout grid on desktop with `gutter-lg` (2rem) and `margin-desktop` (2rem).
  - 8-column layout grid on tablet with `gutter-sm` (1rem) and `margin` (1.5rem).
  - 4-column layout grid on mobile with `space-sm` (0.5rem) column spacing and `margin-mobile` (1rem).

### Vertical Density & Rhythm
- High-density data tables and audit lists use `space-sm` padding vertically.
- Cards, panels, and rule inspection flyouts utilize `space-base` to `space-lg` internal padding.

## Elevation & Depth

Depth is established via subtle surface contrast and multi-stop ambient shadows rather than harsh borders or dark drop shadows.

### Elevation Levels
- **Level 0 (Base Canvas):** Background underlay (`#f8fafc`). Completely flat.
- **Level 1 (Card & Content Panels):** Surface `#ffffff` framed by a clean 1px border (`#e2e8f0`). Ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hovered Cards & Interactive Controls):** Surface `#ffffff` with border `#cbd5e1`. Elevation shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Dropdown Menus & Popovers):** Raised floating components framed by `#e2e8f0`. Elevation shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`.
- **Level 4 (Audit Flyouts & Modal Dialogs):** Overlaid viewports anchored above backdrop `#0f172a` at 40% opacity. Elevation shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system employs a refined geometric curve scale (Roundedness level `2`), softening enterprise rigidity while preserving density and alignment.

### Radius Assignments
- **Micro Surfaces & Badges (0.25rem / 4px):** Semantic status tags, mini pill counters, and segmented control tabs.
- **Interactive Controls (0.5rem / 8px):** Form inputs, default buttons, select triggers, search bars, and dropdown menus.
- **Standard Cards & Panels (`rounded-lg` / 1rem / 16px):** Dashboard summary widgets, rule definition boxes, and data tables.
- **Outer Shell Containers & Modals (`rounded-xl` / 1.5rem / 24px):** Diagnostic inspection modals, rule editor panels, and floating notification stacks.

## Components

### Buttons
- **Primary:** Solid `#6366f1` background, `#ffffff` typography, 0.5rem radius, height 40px (desktop), 36px (compact table action). Hover state darkens to `#4f46e5`. Focus rings display a 2px offset with a 2px `#6366f1` ring.
- **Secondary / Subtle:** Surface `#ffffff`, 1px solid border `#e2e8f0`, text `#0f172a`. Hover transitions to `#f8fafc` background with `#cbd5e1` border.
- **Ghost:** Transparent background, text `#475569`, 0.5rem radius. Hover fills with `#f1f5f9`.
- **Destructive:** Deep rose text `#ef4444` on `#fef2f2` fill for soft destructive, or solid `#ef4444` for irreversible actions.

### Compliance Status Chips & Badges
- Height: 24px. Padding: 0 8px. Font: `label-sm` (11px, weight 600, uppercase or sentence case).
- **Approved / Pass:** `#ecfdf5` background, `#10b981` text, `#a7f3d0` 1px border. Includes a 6px solid green dot prefix.
- **Warning / Review:** `#fffbeb` background, `#d97706` text, `#fde68a` 1px border. Includes a 6px warning amber dot prefix.
- **Violation / Critical:** `#fef2f2` background, `#ef4444` text, `#fecaca` 1px border. Includes a 6px rose dot prefix.
- **AI Engine Tag:** `#f5f3ff` background, `#7c3aed` text, `#ddd6fe` border with sparkle glyph prefix.

### Cards & Panels
- **Container Metric Cards:** `#ffffff` surface, 16px border-radius (`rounded-lg`), 1px border `#e2e8f0`, padding 24px (`space-lg`). Includes a top-right trending indicator or compliance sparkline.
- **Rule Violation Card:** Left border accented with 4px semantic indicator line (`#ef4444` or `#f59e0b`). Background `#ffffff`, containing tokenized snippet comparison (Expected vs. Detected).

### Data Tables
- Header row uses `#f8fafc` surface with 1px bottom border `#e2e8f0`, text styled via `label-sm` in `#475569`.
- Data rows feature 48px height for default density, 40px for compact views. Active row hover applies `#f8fafc`. Row selections apply a tinted indigo highlight (`#eef2ff`).

### Form Inputs & Selectors
- Standard height: 40px, 0.5rem radius, `#ffffff` background, 1px border `#cbd5e1`. Placeholder text uses `#94a3b8`.
- Focus state switches border to `#6366f1` and adds a 3px ring of `#6366f1` at 15% opacity.
- Disabled state applies `#f1f5f9` fill and `#94a3b8` text.

### Checkboxes & Radios
- Size: 16px x 16px. Border radius is 4px for checkboxes, 50% circular for radios.
- Unchecked: `#ffffff` with 1.5px border `#cbd5e1`.
- Checked: `#6366f1` solid fill with crisp white icon checkmark.

### AI Insight Drawer (Product-Specific Component)
- Docked panel (480px width) sliding from the right edge with elevation level 4.
- Divided into analysis header, discrepancy side-by-side diffing, and one-click "Apply Remediation" actions.